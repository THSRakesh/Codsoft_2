import java.util.Scanner;

public class Main {
    static int english,telugu,hindi,maths,science,social,total;
    static float percent;
    public static void main(String[] args) {
        marks();
        System.out.println("\nTotal Marks : "+totalMarks());
        System.out.println("\nAverage Percentage : "+String.format("%.2f",AveragePercentage()));
        grade();
    }


    public static void marks() {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter English Marks(out of 100) : ");
        english = input.nextInt();
        if (english < 0 || english > 100) {
            throw new IllegalArgumentException("Marks should be less than 100 and greater than 0\n\n        Please refresh to ReEnter\n\n");
        }
        input.nextLine();

        System.out.print("Enter Telugu Marks(out of 100) : ");
        telugu = input.nextInt();
        if (telugu < 0 || telugu > 100) {
            throw new IllegalArgumentException("Marks should be less than 100 and greater than 0\n\n        Please refresh to ReEnter\n\n");
        }
        input.nextLine();

        System.out.print("Enter Hindi Marks(out of 100) : ");
        hindi = input.nextInt();
        if (hindi < 0 || hindi > 100) {
            throw new IllegalArgumentException("Marks should be less than 100 and greater than 0\n\n        Please refresh to ReEnter\n\n");
        }
        input.nextLine();

        System.out.print("Enter Maths Marks(out of 100) : ");
        maths = input.nextInt();
        if (maths < 0 || maths > 100) {
            throw new IllegalArgumentException("Marks should be less than 100 and greater than 0\n\n        Please refresh to ReEnter\n\n");
        }
        input.nextLine();

        System.out.print("Enter Science Marks(out of 100) : ");
        science = input.nextInt();
        if (science < 0 || science > 100) {
            throw new IllegalArgumentException("Marks should be less than 100 and greater than 0\n\n        Please refresh to ReEnter\n\n");
        }
        input.nextLine();

        System.out.print("Enter Social Marks(out of 100) : ");
        social = input.nextInt();
        if (social < 0 || social > 100) {
            throw new IllegalArgumentException("Marks should be less than 100 and greater than 0\n\n        Please refresh to ReEnter\n\n");
        }
        input.nextLine();
    }

    public static int totalMarks(){
        total=english+telugu+hindi+maths+science+social;
        return total;
    }

    public static float AveragePercentage(){
        percent=(float)total /6;
        return percent;
    }

    public static void grade(){
        if(percent>90.00){
            System.out.println("\n'O' - Grade");
        }
        else if(percent>80.00){
            System.out.println("\n'A+' - Grade");
        }
        else if (percent>70.00) {
            System.out.println("\n'A' - Grade");
        }
        else if(percent>60.00){
            System.out.println("\n'B+' - Grade");
        }
        else if(percent>50.00){
            System.out.println("\n'B' - Grade");
        }
        else if(percent>40.00){
            System.out.println("\n'C' - Grade");
        }
        else{
            System.out.println("\nFail");
        }
    }
}